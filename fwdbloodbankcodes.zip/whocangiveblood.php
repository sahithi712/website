<html>
<head>
<title>WHO CAN GIVE BLOOD?</title>
<style>
body {
background-image:url("bloodtipsimage.jpg");
background-size: 1800px 3000px;
background-repeat: no-repeat;
font-size:20px;

}
</style>
<body>
<h1 style="text-align:center"><strong>WHO CAN GIVE BLOOD?</strong></h1>

<p>

<br>

<b>The common reasons donors should check if they can give blood are:</b>
<br>
<br>1.if you are receiving medical or hospital treatment
<br>2.if you are taking medication
<br>3.after travelling outside of the UK
<br>4.after having a tattoo or piercing
<br>5.during and after pregnancy
<br>6.if you feel ill
<br>7.if you have cancer
<br>8.after receiving blood, blood products or organs.
<br>
<br>
<b>Male and female donors</b>
<br>
<br>Men often make ideal donors because:
<br>
<br>mens additional body weight means they have suitable iron levels
<br>they are less likely than women to carry certain immune cells meaning their plasma is more widely usable for transfusions
<br>their platelet count is typically higher meaning they are more likely to be accepted as platelet donors.
<br><b>Women under 20 - check if you can give blood</b>
<br>
<br>If you are a woman under 20 and you weigh under 10st 3lb or 65kg or are under 5' 6" or 168cm tall you will need to estimate your blood volume to see if you can give blood. If your weight lies between two of the values shown, please use the nearest lower weight.

<br></p>
</body>
</head>
</html>
</br>

<br></p>
</body>
</head>
</html>
