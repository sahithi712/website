<html>
<head>
<title>WHY GIVE BLOOD?</title>
<style>
body {
background-image:url("bloodtipsimage.jpg");
background-size: 1800px 3000px;
background-repeat: no-repeat;
font-size:20px;

}
</style>
<body>
<h1 style="text-align:center"><strong>WHY GIVE BLOOD?</strong></h1>

<p>

<br>


Giving blood saves lives. The blood you give is a lifeline in an emergency and for people who need long-term treatments.
<br>
<br>Many people would not be alive today if donors had not generously given their blood.
<br><br>
<b>Why we need you to give blood</b>
<br>
<br>Most people between the ages of 17-65 are able to give blood.
<br>
<br>Around half our current donors are over 45. That's why we need more young people (over the age of 17) to start giving blood.
<br><br>Find out who can give blood, and then book an appointment to give blood.
<br>
<br>
<b>About blood</b>
<br>

<br>Blood has many different parts or components including red blood cells, plasma and platelets.
<br>
<br>It is also classified into different blood groups and blood types.

<br></p>
</body>
</head>
</html>
</br>

<br></p>
</body>
</head>
</html>
