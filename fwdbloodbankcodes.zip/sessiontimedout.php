<html>
<head></head>
<body>
	<h1>SESSION TIMED OUT</h1>
	click here to login again<a href="login1.php">login</a></p>
</body>
</html>