<?php
DEFINE ('DB_USER','89dbuser1');
DEFINE ('DB_PSWD','dbpass1');
DEFINE ('DB_HOST','db1.webdev89.cocc-webdev.org');
DEFINE ('DB_NAME','webdev89db1');
$dbcon=mysql_connect(DB_HOST,DB_USER,DB_PSWD,DB_NAME);
?>