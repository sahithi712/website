<html>
<head>
<style>
input:checked {
    height: 50px;
    width: 50px;}
div {
    background-color: white;
    width: 300px;
height:330px;
    border: 16px solid red;
    padding: 8px;
    margin: 15px;
align-items:center;
}
body {
background-image:url("image9.jpg");
background-size: 1600px 800px;
background-repeat: no-repeat;
padding-top:200px; 
}
a:link{
text-decoration: none;}
h1{
font-size:50px;}

form{
font-family:verdana;
font-size:35px;

}
</style>
</head>
<body style="text-align:center;">

<div>
<h1 style="text-align:center;"><strong><b>LOGIN</b></strong></h1>
<form>
 <br><a href="donor.php" target="_blank"> DONOR</a><br>

 <br><a href="acceptor.php" target="_blank">ACCEPTOR</a><br>
   
</form> 
</div>


</body>
</html>
